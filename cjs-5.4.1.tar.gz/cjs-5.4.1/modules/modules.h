/* -*- mode: C++; c-basic-offset: 4; indent-tabs-mode: nil; -*- */
// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2013 Red Hat, Inc.

#ifndef MODULES_MODULES_H_
#define MODULES_MODULES_H_

void gjs_register_static_modules (void);

#endif  // MODULES_MODULES_H_
