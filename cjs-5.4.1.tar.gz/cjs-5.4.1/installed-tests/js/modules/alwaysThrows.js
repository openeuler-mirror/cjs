// line 0
// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2008 litl, LLC
throw new Error('This is an error that always happens on line 3');
