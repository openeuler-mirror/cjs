// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2020 Philip Chimento <philip.chimento@gmail.com>

export function say(str) {
    return `<( ${str} )`;
}

export default function () {
    return 'default export';
}
