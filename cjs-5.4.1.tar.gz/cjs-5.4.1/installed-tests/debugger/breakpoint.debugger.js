// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2018 Philip Chimento <philip.chimento@gmail.com>
print('1');
print('2');
function foo() {
    print('Function foo');
}
print('3');
foo();
