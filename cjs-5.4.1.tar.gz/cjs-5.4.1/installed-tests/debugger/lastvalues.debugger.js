// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2020 Philip Chimento <philip.chimento@gmail.com>
const a = undefined;
const b = null;
const c = 42;
debugger;
void (a, b, c);
