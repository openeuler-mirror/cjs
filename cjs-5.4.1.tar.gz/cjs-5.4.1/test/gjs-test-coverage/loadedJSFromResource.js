// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2014 Endless Mobile, Inc.

/* eslint-disable jsdoc/require-jsdoc */

/* exported mockFunction */
function mockFunction() {}
