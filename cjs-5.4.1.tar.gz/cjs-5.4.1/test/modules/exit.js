// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2021 Philip Chimento <philip.chimento@gmail.com>

import System from 'system';
System.exit(42);
